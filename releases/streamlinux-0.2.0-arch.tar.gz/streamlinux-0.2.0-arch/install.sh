#!/bin/bash
set -e
if [ "$EUID" -ne 0 ]; then echo "Run as root: sudo ./install.sh"; exit 1; fi

echo "Installing StreamLinux for Arch Linux..."

# Install dependencies
pacman -Sy --noconfirm --needed python python-gobject gtk4 libadwaita \
    gst-plugins-bad gst-plugins-good gst-plugins-base gstreamer \
    pipewire pipewire-gstreamer qrencode

# Create directories
mkdir -p /opt/streamlinux/bin
mkdir -p /opt/streamlinux/data

# Copy files
cp *.py /opt/streamlinux/
cp -r data/* /opt/streamlinux/data/
cp signaling-server /opt/streamlinux/bin/
chmod +x /opt/streamlinux/bin/signaling-server

# Create launcher
cat > /usr/local/bin/streamlinux << 'EOF'
#!/bin/bash
cd /opt/streamlinux
exec python3 streamlinux_gui.py "$@"
EOF
chmod +x /usr/local/bin/streamlinux

# Desktop file
cat > /usr/share/applications/streamlinux.desktop << 'EOF'
[Desktop Entry]
Name=StreamLinux
Comment=Stream your Linux desktop to Android
Exec=streamlinux
Icon=/opt/streamlinux/data/icons/streamlinux.svg
Terminal=false
Type=Application
Categories=AudioVideo;Video;Network;
EOF

echo "StreamLinux installed! Launch from menu or run: streamlinux"
