#!/bin/bash
set -e
if [ "$EUID" -ne 0 ]; then echo "Run as root: sudo ./install.sh"; exit 1; fi
echo "Installing StreamLinux..."
pacman -S --needed --noconfirm python python-gobject gtk4 libadwaita \
    gst-plugins-bad gst-plugins-good gst-plugins-base \
    pipewire qrencode
mkdir -p /opt/streamlinux/bin /opt/streamlinux/data
cp *.py /opt/streamlinux/
cp -r data/* /opt/streamlinux/data/
cp signaling-server /opt/streamlinux/bin/
chmod +x /opt/streamlinux/bin/signaling-server
cat > /usr/local/bin/streamlinux << 'EOF'
#!/bin/bash
cd /opt/streamlinux
exec python3 streamlinux_gui.py "$@"
EOF
chmod +x /usr/local/bin/streamlinux
cat > /usr/share/applications/streamlinux.desktop << 'EOF'
[Desktop Entry]
Name=StreamLinux
Comment=Stream your Linux desktop to Android
Exec=streamlinux
Icon=/opt/streamlinux/data/icons/streamlinux.svg
Terminal=false
Type=Application
Categories=AudioVideo;Video;Network;
EOF
echo "StreamLinux installed! Launch from menu or run: streamlinux"
