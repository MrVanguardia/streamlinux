#!/bin/bash
set -e
if [ "$EUID" -ne 0 ]; then echo "Run as root: sudo ./install.sh"; exit 1; fi

echo "Installing StreamLinux..."

# Install dependencies
apt-get update -qq
apt-get install -y -qq python3 python3-gi python3-gi-cairo \
    gir1.2-gtk-4.0 gir1.2-adw-1 gstreamer1.0-plugins-bad \
    gstreamer1.0-plugins-good gstreamer1.0-plugins-base \
    gstreamer1.0-pipewire pipewire libqrencode4

# Create directories
mkdir -p /opt/streamlinux/bin
mkdir -p /opt/streamlinux/data

# Copy files
cp *.py /opt/streamlinux/
cp -r data/* /opt/streamlinux/data/
cp signaling-server /opt/streamlinux/bin/
chmod +x /opt/streamlinux/bin/signaling-server

# Create launcher
cat > /usr/local/bin/streamlinux << 'EOF'
#!/bin/bash
cd /opt/streamlinux
exec python3 streamlinux_gui.py "$@"
EOF
chmod +x /usr/local/bin/streamlinux

# Desktop file
cat > /usr/share/applications/streamlinux.desktop << 'EOF'
[Desktop Entry]
Name=StreamLinux
Comment=Stream your Linux desktop to Android
Exec=streamlinux
Icon=/opt/streamlinux/data/icons/streamlinux.svg
Terminal=false
Type=Application
Categories=AudioVideo;Video;Network;
EOF

echo "StreamLinux installed! Launch from menu or run: streamlinux"
